<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class UserController extends Controller
{
    public function pusatSaya()
    {
        return view('pusat_saya');
    }
}
