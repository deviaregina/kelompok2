<!DOCTYPE html>
<html>
<head><title>Dashboard</title></head>
<body>
    <h2>Selamat datang, <?= $user['name'] ?></h2>
    <a href="/auth/logout">Logout</a>
</body>
</html>
