<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h2>Halo, <?= session('user_name') ?>!</h2>
    <p>Selamat datang di dashboard.</p>
    <a href="/logout">Logout</a>
</body>
</html>
