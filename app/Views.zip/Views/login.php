php
   <!DOCTYPE html>
   <html lang="id">
   <head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>Login</title>
       <style>
           body {
               font-family: Arial, sans-serif;
               background-color: #f9f9f9;
               margin: 0;
               padding: 0;
           }
           .login-container {
               max-width: 400px;
               margin: 50px auto;
               padding: 20px;
               background: white;
               border-radius: 8px;
               box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
           }
           .login-header {
               text-align: center;
               margin-bottom: 20px;
           }
           .login-header h2 {
               color: #ff4081;
               margin: 0;
           }
           .form-group {
               margin-bottom: 15px;
           }
           .form-group label {
               display: block;
               margin-bottom: 5px;
           }
           .form-group input {
               width: 100%;
               padding: 10px;
               border: 1px solid #ddd;
               border-radius: 5px;
           }
           .login-button {
               width: 100%;
               padding: 10px;
               background-color: #ff4081;
               border: none;
               color: white;
               font-size: 16px;
               border-radius: 5px;
               cursor: pointer;
           }
           .login-button:hover {
               background-color: #e03671;
           }
           .alternative-login {
               text-align: center;
               margin-top: 15px;
           }
           .alternative-login img {
               width: 40px;
               margin: 0 10px;
               cursor: pointer;
           }
           .forgot-password {
               text-align: center;
               margin-top: 15px;
           }
           .forgot-password a {
               color: #007bff;
               text-decoration: none;
           }
       </style>
   </head>
   <body>
       <div class="login-container">
           <div class="login-header">
               <h2>MASUK</h2>
           </div>
           <form action="/login" method="POST">
               <div class="form-group">
                   <label for="email">ID/Email</label>
                   <input type="text" id="email" name="email" placeholder="Masukkan ID/Email">
               </div>
               <div class="form-group">
                   <label for="password">Kata Sandi</label>
                   <input type="password" id="password" name="password" placeholder="Masukkan Kata Sandi">
               </div>
               <button type="submit" class="login-button">MASUK</button>
               <div class="forgot-password">
                   <a href="#">Tidak ingat kata sandi?</a>
               </div>
               <div class="alternative-login">
                   <img src="facebook-icon.png" alt="Facebook">
                   <img src="vk-icon.png" alt="VK">
                   <img src="apple-icon.png" alt="Apple">
               </div>
           </form>
       </div>
   </body>
   </html>