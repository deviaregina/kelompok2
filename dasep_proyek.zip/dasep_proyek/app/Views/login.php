<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            border-radius: 10px;
            background: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .login-container h3 {
            margin-bottom: 20px;
        }
        .social-icons img {
            width: 40px;
            margin: 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h3>MASUK</h3>
    
    <ul class="nav nav-tabs mb-3">
        <li class="nav-item">
            <a class="nav-link active" href="#">Masuk Akun</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">Login melalui Telepon</a>
        </li>
    </ul>

    <form action="#" method="post">
        <div class="mb-3">
            <input type="text" class="form-control" name="email" placeholder="ID/Email">
        </div>
        <div class="mb-3">
            <input type="password" class="form-control" name="password" placeholder="Kata Sandi">
        </div>
        <button type="submit" class="btn btn-danger w-100">MASUK</button>
    </form>

    <a href="#" class="d-block mt-3 text-primary">Tidak ingat kata sandi?</a>

    <p class="mt-3">Metode login lainnya</p>
    <div class="social-icons">
        <img src="https://upload.wikimedia.org/wikipedia/commons/0/05/Facebook_Logo_%282019%29.png" alt="Facebook">
        <img src="https://upload.wikimedia.org/wikipedia/commons/3/3f/VK.com-logo.svg" alt="VK">
        <img src="https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg" alt="Apple">
    </div>
</div>

</body>
</html>
