<footer>
    <a href="<?= base_url('training') ?>">Training</a>
    <a href="<?= base_url('mall') ?>">Mall</a>
    <a href="<?= base_url('berita') ?>">Berita</a>
    <a href="<?= base_url('member') ?>">Member</a>
    <a href="<?= base_url('pusat-saya') ?>" class="active">Pusat Saya</a>
</footer>
