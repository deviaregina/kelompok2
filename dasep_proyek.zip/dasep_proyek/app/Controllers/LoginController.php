<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class LoginController extends Controller
{
    public function index()
    {
        return view('login');
    }

    public function login()
    {
        $session = session();
        $userModel = new UserModel();

        // Validasi input dari form login
        $validation = \Config\Services::validation();
        $validation->setRules([
            'email'    => 'required|valid_email',
            'password' => 'required|min_length[6]'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            $session->setFlashdata('error', 'Email atau password tidak valid.');
            return redirect()->to('/login')->withInput();
        }

        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $user = $userModel->where('email', $email)->first();

        if (!$user) {
            $session->setFlashdata('error', 'Email tidak ditemukan.');
            return redirect()->to('/login');
        }

        if (!password_verify($password, $user['password'])) {
            $session->setFlashdata('error', 'Password salah.');
            return redirect()->to('/login');
        }

        // Set session data jika login berhasil
        $sessionData = [
            'id'        => $user['id'],
            'name'      => $user['name'],
            'email'     => $user['email'],
            'logged_in' => true
        ];
        $session->set($sessionData);

        // Redirect ke halaman pusat saya
        return redirect()->to('/pusat-saya');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
